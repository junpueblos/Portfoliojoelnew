import { useCallback, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { EASE, Eyebrow } from "./ui";

const QUOTES = [
  {
    text: "Professional, reliable, and easy to work with. The website looked amazing and the results from our marketing campaigns exceeded expectations!",
    name: "Sarah M.",
    role: "Business Owner",
    img: "images/avatar-sarah.jpg",
  },
  {
    text: "Joel automated our entire onboarding sequence in under a week. What used to take my team two days now runs without anyone touching it.",
    name: "Mark Dela Cruz",
    role: "Startup Founder",
    img: "images/avatar-mark.jpg",
  },
  {
    text: "He understood my brand voice immediately. The landing page he built finally converts the traffic I was paying for — bookings doubled in a month.",
    name: "Angela Reyes",
    role: "Coach & Consultant",
    img: "images/avatar-angela.jpg",
  },
  {
    text: "Clear communication, on schedule, and genuinely strategic. Joel is the rare assistant who thinks like a marketing partner rather than a task-taker.",
    name: "James Carter",
    role: "Marketing Director",
    img: "",
  },
];

export default function Testimonials() {
  const [i, setI] = useState(0);
  const reduce = useReducedMotion();
  const q = QUOTES[i];

  const move = useCallback((d: number) => {
    setI((v) => (v + d + QUOTES.length) % QUOTES.length);
  }, []);

  return (
    <section className="relative overflow-hidden bg-paper py-14 lg:py-20">
      <img
        src="images/marble.jpg"
        alt=""
        aria-hidden
        className="absolute inset-0 h-full w-full object-cover opacity-70"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-white/40 via-transparent to-white/50" />

      <div className="shell relative grid items-start gap-y-9 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.6fr)] lg:gap-x-16">
        <div>
          <Eyebrow tone="light">Client Feedback</Eyebrow>
          <h2 className="mt-5 font-display text-[27px] leading-[1.12] font-bold tracking-[-0.02em] text-[#17150f] sm:text-[34px]">
            What Clients Say
          </h2>
        </div>

        <div className="relative">
          <div className="flex gap-6">
            <span
              aria-hidden
              className="mt-1 shrink-0 font-display text-[54px] leading-[0.8] font-extrabold text-gold select-none"
            >
              &ldquo;
            </span>

            <div className="min-h-[168px] sm:min-h-[150px]">
              <AnimatePresence mode="wait">
                <motion.blockquote
                  key={i}
                  initial={reduce ? { opacity: 1 } : { opacity: 0, y: 14 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={reduce ? { opacity: 1 } : { opacity: 0, y: -10 }}
                  transition={{ duration: 0.45, ease: EASE }}
                >
                  <p className="max-w-[42rem] text-[15.5px] leading-[1.72] text-[#2a251f]">
                    {q.text}
                  </p>
                  <figcaption className="mt-6 flex items-center gap-3.5">
                    {q.img ? (
                      <img
                        src={q.img}
                        alt=""
                        className="h-11 w-11 rounded-full object-cover ring-1 ring-black/10"
                        loading="lazy"
                      />
                    ) : (
                      <span
                        aria-hidden
                        className="flex h-11 w-11 items-center justify-center rounded-full bg-[#17150f] font-display text-[14px] font-bold tracking-[0.04em] text-gold ring-1 ring-black/10"
                      >
                        JC
                      </span>
                    )}
                    <span>
                      <span className="block font-display text-[14.5px] font-semibold text-[#17150f]">
                        {q.name}
                      </span>
                      <span className="block text-[13px] text-[#7d766c]">{q.role}</span>
                    </span>
                  </figcaption>
                </motion.blockquote>
              </AnimatePresence>
            </div>
          </div>

          <div className="mt-10 flex items-center justify-end gap-6">
            <LightArrow dir="prev" onClick={() => move(-1)} />
            <div className="flex items-center gap-2.5">
              {QUOTES.map((qq, n) => (
                <button
                  key={qq.name}
                  type="button"
                  aria-label={`Show testimonial ${n + 1}`}
                  aria-current={n === i}
                  onClick={() => setI(n)}
                  className={`h-2 rounded-full transition-all duration-300 ${
                    n === i ? "w-6 bg-[#c88a20]" : "w-2 bg-black/20 hover:bg-black/40"
                  }`}
                />
              ))}
            </div>
            <LightArrow dir="next" onClick={() => move(1)} />
          </div>
        </div>
      </div>
    </section>
  );
}

function LightArrow({
  dir,
  onClick,
}: {
  dir: "prev" | "next";
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={dir === "prev" ? "Previous testimonial" : "Next testimonial"}
      className="flex h-10 w-10 items-center justify-center rounded-full border border-black/20 bg-white/60 text-[#3a342c] transition-all duration-300 hover:border-[#c88a20] hover:bg-[#17150f] hover:text-gold"
    >
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
        className={`h-4 w-4 ${dir === "next" ? "rotate-180" : ""}`}
        aria-hidden
      >
        <path d="M15 6l-6 6 6 6" />
      </svg>
    </button>
  );
}
