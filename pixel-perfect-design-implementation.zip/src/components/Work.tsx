import { useCallback, useRef, useState } from "react";
import { Reveal, SectionHead, Arrow } from "./ui";

const PROJECTS = [
  {
    title: "Website Design & Development",
    sub: "Modern, conversion-focused websites",
    img: "images/work-web.jpg",
    tag: "Web Design",
  },
  {
    title: "Landing Page & Website Copy",
    sub: "High-converting landing pages",
    img: "images/work-landing.jpg",
    tag: "Copy & Design",
  },
  {
    title: "Digital Marketing Campaign",
    sub: "Paid ads, email marketing, and social media",
    img: "images/work-dashboard.jpg",
    tag: "Marketing",
  },
  {
    title: "Automation & AI Workflows",
    sub: "Automations that give hours back every week",
    img: "images/work-automation.jpg",
    tag: "Automation",
  },
];

export default function Work() {
  const trackRef = useRef<HTMLDivElement>(null);
  const cardRefs = useRef<Array<HTMLDivElement | null>>([]);
  const [index, setIndex] = useState(0);

  const goTo = useCallback((i: number) => {
    const track = trackRef.current;
    const card = cardRefs.current[i];
    if (!track || !card) return;
    const next = Math.max(0, Math.min(PROJECTS.length - 1, i));
    track.scrollTo({ left: card.offsetLeft - track.offsetLeft, behavior: "smooth" });
    setIndex(next);
  }, []);

  const onScroll = useCallback(() => {
    const track = trackRef.current;
    if (!track) return;
    const max = track.scrollWidth - track.clientWidth;
    const p = max > 8 ? track.scrollLeft / max : 0;
    setIndex(Math.round(p * (PROJECTS.length - 1)));
  }, []);

  return (
    <section id="work" className="relative overflow-hidden bg-ink-2 py-16 lg:py-24">
      <div className="shell">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHead eyebrow="Featured Work" title="Selected Projects" />
          <Reveal delay={0.08}>
            <a
              href="#contact"
              className="group inline-flex items-center gap-2.5 rounded-md border border-gold/60 px-6 py-3.5 text-[14px] font-semibold text-gold transition-all duration-300 hover:-translate-y-0.5 hover:border-gold hover:bg-gold/10"
            >
              View All Projects
              <Arrow />
            </a>
          </Reveal>
        </div>

        <div className="relative mt-10">
          {/* desktop arrows, sitting out in the margin like the original */}
          <div className="pointer-events-none absolute inset-y-0 -left-12 hidden items-start pt-[70px] lg:flex xl:-left-14">
            <ArrowBtn dir="prev" onClick={() => goTo(index - 1)} />
          </div>
          <div className="pointer-events-none absolute inset-y-0 -right-12 hidden items-start pt-[70px] lg:flex xl:-right-14">
            <ArrowBtn dir="next" onClick={() => goTo(index + 1)} />
          </div>

          <div
            ref={trackRef}
            onScroll={onScroll}
            className="no-bar flex snap-x snap-mandatory gap-6 overflow-x-auto pb-1"
          >
            {PROJECTS.map((p, i) => (
              <div
                key={p.title}
                ref={(el) => {
                  cardRefs.current[i] = el;
                }}
                className="group w-[84%] shrink-0 snap-start sm:w-[47%] lg:w-[31.5%]"
              >
                <Reveal delay={0.05 * i}>
                  <a href="#contact" className="block">
                    <div className="relative overflow-hidden bg-[#0d0c0b]">
                      <img
                        src={p.img}
                        alt={p.title}
                        loading="lazy"
                        className="aspect-[16/10] w-full object-cover transition-transform duration-[900ms] ease-out group-hover:scale-[1.05]"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-transparent to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
                      <span className="eyebrow absolute bottom-4 left-4 translate-y-2 text-gold opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100">
                        {p.tag}
                      </span>
                    </div>
                    <div className="mt-4 flex items-start gap-3">
                      <span className="mt-2.5 block h-px w-6 shrink-0 bg-gold transition-all duration-500 group-hover:w-12" />
                      <div>
                        <h3 className="font-display text-[15.5px] leading-snug font-semibold text-white transition-colors duration-300 group-hover:text-gold">
                          {p.title}
                        </h3>
                        <p className="mt-1.5 text-[13.5px] leading-snug text-mute">{p.sub}</p>
                      </div>
                    </div>
                  </a>
                </Reveal>
              </div>
            ))}
          </div>
        </div>

        {/* controls */}
        <div className="mt-9 flex items-center justify-center gap-5">
          <div className="flex gap-3 lg:hidden">
            <ArrowBtn dir="prev" onClick={() => goTo(index - 1)} />
          </div>
          <div className="flex items-center gap-2.5">
            {PROJECTS.map((p, i) => (
              <button
                key={p.title}
                type="button"
                aria-label={`Go to project ${i + 1}`}
                aria-current={index === i}
                onClick={() => goTo(i)}
                className={`h-2 rounded-full transition-all duration-300 ${
                  index === i ? "w-6 bg-gold" : "w-2 bg-white/25 hover:bg-white/50"
                }`}
              />
            ))}
          </div>
          <div className="flex gap-3 lg:hidden">
            <ArrowBtn dir="next" onClick={() => goTo(index + 1)} />
          </div>
        </div>
      </div>
    </section>
  );
}

function ArrowBtn({
  dir,
  onClick,
}: {
  dir: "prev" | "next";
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={dir === "prev" ? "Previous projects" : "Next projects"}
      className="pointer-events-auto flex h-11 w-11 items-center justify-center rounded-full border border-white/25 bg-ink/70 text-sand backdrop-blur-sm transition-all duration-300 hover:border-gold hover:bg-gold hover:text-[#14100a]"
    >
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
        className={`h-4 w-4 ${dir === "next" ? "rotate-180" : ""}`}
        aria-hidden
      >
        <path d="M15 6l-6 6 6 6" />
      </svg>
    </button>
  );
}
