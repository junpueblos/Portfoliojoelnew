import { motion, useReducedMotion } from "framer-motion";
import { Arrow, EASE } from "./ui";

const STATS = [
  { n: "6+", label: "Years Virtual\nAssistance" },
  { n: "6+", label: "Years Website\nExperience" },
  { n: "6+", label: "Years Marketing\nExperience" },
  { n: "∞", label: "Continuous Learning\n(Automation & AI)" },
];

const LINES = [
  { text: "Technical Virtual Assistant", tone: "white" },
  { text: "AI Digital Specialist", tone: "gold" },
  { text: "Web Design & Digital Marketing", tone: "white" },
];

export default function Hero() {
  const reduce = useReducedMotion();

  const line = (i: number) => ({
    initial: reduce ? { opacity: 1 } : { opacity: 0, y: 28 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.7, delay: 0.15 + i * 0.09, ease: EASE },
  });

  return (
    <section id="home" className="relative isolate overflow-hidden bg-ink">
      {/* Portrait bleed, right edge */}
      <div className="pointer-events-none absolute inset-y-0 right-0 w-full md:w-[54%] lg:w-[47%]">
        <img
          src="images/hero-portrait.jpg"
          alt="Joel Pueblos, technical virtual assistant and AI digital specialist"
          className="h-full w-full object-cover object-[52%_16%]"
          loading="eager"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/90 to-ink/62 md:via-ink/72 md:to-transparent" />
        <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-ink via-ink/70 to-transparent" />
        <div className="absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-ink/85 to-transparent" />

        {/* handwritten signature + tracked stamp */}
        <motion.div
          initial={reduce ? { opacity: 1 } : { opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.85, ease: EASE }}
          className="absolute right-5 bottom-16 hidden text-right sm:block lg:right-10 lg:bottom-20"
        >
          <p className="font-script text-[34px] leading-[1.05] text-gold drop-shadow-[0_2px_14px_rgba(0,0,0,0.55)] lg:text-[42px]">
            Ideas
            <br />
            Automation
            <br />
            <span className="inline-block -translate-x-4 lg:-translate-x-6">Growth</span>
          </p>
        </motion.div>
        <motion.p
          initial={reduce ? { opacity: 1 } : { opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1.1 }}
          className="absolute right-5 bottom-5 hidden text-right text-[9px] leading-[1.7] tracking-[0.28em] text-white/70 sm:block lg:right-10 lg:bottom-7"
        >
          PEOPLE
          <br />
          SYSTEMS
          <br />
          DIGITAL RESULTS
        </motion.p>
      </div>

      <div className="shell relative z-10 pt-[116px] pb-14 md:pt-[136px] md:pb-20 lg:pt-[150px] lg:pb-24">
        <motion.div
          initial={reduce ? { opacity: 1 } : { opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, ease: EASE }}
          className="flex items-center gap-4"
        >
          <motion.span
            className="block h-px w-10 bg-gold"
            initial={reduce ? { width: 40 } : { width: 0 }}
            animate={{ width: 40 }}
            transition={{ duration: 0.7, delay: 0.1, ease: EASE }}
          />
          <span className="eyebrow text-sand/75">
            Your Partner in a Smarter Digital Tomorrow
          </span>
        </motion.div>

        <h1 className="mt-7 max-w-[900px] font-display text-[31px] leading-[1.1] font-bold tracking-[-0.03em] text-white sm:text-[40px] lg:text-[46px] xl:text-[52px]">
          {LINES.map((l, i) => (
            <motion.span
              key={l.text}
              {...line(i)}
              className={`block ${l.tone === "gold" ? "text-gold" : "text-white"}`}
            >
              {l.text}
            </motion.span>
          ))}
        </h1>

        <motion.p
          {...line(3)}
          className="mt-6 max-w-[30rem] text-[16.5px] leading-[1.6] text-mute"
        >
          Helping businesses build, automate, and grow their online presence with
          practical digital solutions.
        </motion.p>

        <motion.div
          {...line(4)}
          className="mt-7 flex flex-wrap items-center gap-x-5 gap-y-3 text-[14.5px] text-sand/90"
        >
          <span className="inline-flex items-center gap-2">
            <PinIcon />
            Philippines
          </span>
          <span className="hidden h-4 w-px bg-white/20 sm:block" />
          <span className="inline-flex items-center gap-2">
            <GlobeIcon />
            Available for Remote &amp; International Clients
          </span>
        </motion.div>

        <motion.div {...line(5)} className="mt-9 flex flex-wrap items-center gap-4">
          <a
            href="#contact"
            className="group inline-flex items-center gap-2.5 rounded-md bg-gold px-7 py-4 text-[14.5px] font-semibold text-[#14100a] transition-all duration-300 hover:-translate-y-0.5 hover:bg-gold-100 hover:shadow-[0_14px_34px_-14px_rgba(242,180,65,0.7)]"
          >
            Let&apos;s Work Together
            <Arrow />
          </a>
          <a
            href="#work"
            className="group inline-flex items-center gap-2.5 rounded-md border border-gold/60 px-7 py-4 text-[14.5px] font-semibold text-gold transition-all duration-300 hover:-translate-y-0.5 hover:border-gold hover:bg-gold/10"
          >
            View My Work
          </a>
        </motion.div>

        <motion.dl
          {...line(6)}
          className="mt-12 grid max-w-[640px] grid-cols-2 gap-y-7 border-t border-white/[0.08] pt-8 sm:grid-cols-4 sm:gap-y-0"
        >
          {STATS.map((s, i) => (
            <div
              key={s.label}
              className={[
                "pr-5",
                i === 0 ? "pl-0" : "pl-5",
                i === 1 || i === 3 ? "border-l border-white/[0.12]" : "",
                i === 2 ? "sm:border-l sm:border-white/[0.12] pl-0 sm:pl-5" : "",
                i >= 2 ? "max-sm:border-t max-sm:border-white/[0.12] max-sm:pt-7" : "",
              ].join(" ")}
            >
              <dt className="tnum font-display text-[32px] leading-none font-bold text-gold lg:text-[36px]">
                {s.n}
              </dt>
              <dd className="mt-3 text-[13.5px] leading-[1.45] whitespace-pre-line text-mute">
                {s.label}
              </dd>
            </div>
          ))}
        </motion.dl>
      </div>

    </section>
  );
}

function PinIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4 text-gold" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 1116 0z" />
      <circle cx="12" cy="10" r="3" />
    </svg>
  );
}

function GlobeIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4 text-gold" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <circle cx="12" cy="12" r="9" />
      <path d="M3 12h18M12 3c2.5 2.6 3.8 5.7 3.8 9S14.5 18.4 12 21c-2.5-2.6-3.8-5.7-3.8-9S9.5 5.6 12 3z" />
    </svg>
  );
}
