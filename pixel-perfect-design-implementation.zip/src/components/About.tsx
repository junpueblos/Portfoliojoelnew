import { Arrow, Reveal, SectionHead } from "./ui";

const SERVICES = [
  {
    title: "Web Design\n& Development",
    body: "Modern, responsive websites and landing pages that convert.",
    icon: (
      <>
        <rect x="2.5" y="4" width="19" height="13" rx="1.6" />
        <path d="M8.5 21h7M12 17v4" />
      </>
    ),
  },
  {
    title: "Digital Marketing",
    body: "Paid ads, email marketing, social media strategy, and marketing funnels.",
    icon: (
      <>
        <path d="M4 10.5v3a1.5 1.5 0 001.5 1.5H8l7 4.5V6L8 10.5H5.5A1.5 1.5 0 004 12z" />
        <path d="M18 9.5a4 4 0 010 5" />
      </>
    ),
  },
  {
    title: "Automation & AI",
    body: "Streamline your business with automation and AI-powered workflows.",
    icon: (
      <>
        <circle cx="12" cy="12" r="3.2" />
        <path d="M12 2.8v2.6M12 18.6v2.6M4.5 12H1.9M22.1 12h-2.6M6.7 6.7L4.9 4.9M19.1 19.1l-1.8-1.8M6.7 17.3l-1.8 1.8M19.1 4.9l-1.8 1.8" />
      </>
    ),
  },
  {
    title: "Virtual Assistance",
    body: "Reliable technical and administrative support for your online business.",
    icon: (
      <>
        <circle cx="12" cy="8" r="3.6" />
        <path d="M4.5 20.5c0-3.6 3.4-6 7.5-6s7.5 2.4 7.5 6" />
      </>
    ),
  },
];

export default function About() {
  return (
    <section id="about" className="relative bg-ink-3 py-16 lg:py-24">
      <div className="shell grid items-start gap-y-12 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.05fr)] lg:gap-x-16">
        {/* Prose column */}
        <div>
          <SectionHead
            eyebrow="About Me"
            title={
              <>
                Turning Digital
                <br />
                Expertise into Real Results
              </>
            }
          />

          <Reveal delay={0.05}>
            <p className="mt-6 max-w-[36rem] text-[15px] leading-[1.72] text-mute">
              I&apos;m Joel Pueblos, a Technical Virtual Assistant and AI Digital
              Specialist with 6 years of experience in virtual assistance, website
              development and design, and digital marketing. I help online service
              providers, small businesses, startups, coaches, consultants, and
              international clients build a strong online presence, streamline
              operations, and grow their businesses through practical and effective
              digital solutions.
            </p>
          </Reveal>

          <Reveal delay={0.1}>
            <a
              href="#services"
              className="group mt-8 inline-flex items-center gap-2.5 rounded-md border border-gold/60 px-6 py-3.5 text-[14px] font-semibold text-gold transition-all duration-300 hover:-translate-y-0.5 hover:border-gold hover:bg-gold/10"
            >
              More About Me
              <Arrow />
            </a>
          </Reveal>
        </div>

        {/* Spec grid — hairlines do the dividing, no cards */}
        <div
          id="services"
          className="grid scroll-mt-24 border-white/[0.10] sm:grid-cols-2 sm:border-l sm:pl-8"
        >
          {SERVICES.map((s, i) => (
            <Reveal
              key={s.title}
              delay={0.06 * i}
              className={[
                "group border-white/[0.10] py-7",
                i === 0 ? "border-b sm:pr-8" : "",
                i === 1 ? "border-b sm:pl-8 sm:border-l" : "",
                i === 2 ? "max-sm:border-b sm:pr-8" : "",
                i === 3 ? "sm:pl-8 sm:border-l" : "",
              ].join(" ")}
            >
              <div className="flex items-start gap-5">
                <svg
                  viewBox="0 0 24 24"
                  className="mt-0.5 h-8 w-8 shrink-0 text-gold transition-transform duration-300 group-hover:-translate-y-0.5"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.4"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  aria-hidden
                >
                  {s.icon}
                </svg>
                <div>
                  <h3 className="font-display text-[15.5px] leading-[1.3] font-semibold whitespace-pre-line text-white">
                    {s.title}
                  </h3>
                  <p className="mt-2.5 max-w-[24rem] text-[13.5px] leading-[1.6] text-mute">
                    {s.body}
                  </p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
