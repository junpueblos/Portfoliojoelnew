import { motion, useReducedMotion } from "framer-motion";
import type { ReactNode } from "react";

const EASE = [0.22, 1, 0.36, 1] as const;

export function Reveal({
  children,
  delay = 0,
  y = 24,
  className = "",
  as = "div",
}: {
  children: ReactNode;
  delay?: number;
  y?: number;
  className?: string;
  as?: "div" | "li";
}) {
  const reduce = useReducedMotion();
  const M = as === "li" ? motion.li : motion.div;
  return (
    <M
      className={className}
      initial={reduce ? { opacity: 1 } : { opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.6, delay, ease: EASE }}
    >
      {children}
    </M>
  );
}

/** Short gold rule that draws itself in — the signature section marker. */
export function Rule({ tone = "gold" }: { tone?: "gold" | "ink" }) {
  const reduce = useReducedMotion();
  return (
    <motion.span
      aria-hidden
      className="block h-px w-10 shrink-0"
      style={{ backgroundColor: tone === "gold" ? "#f2b441" : "#17150f" }}
      initial={reduce ? { width: 40 } : { width: 0 }}
      whileInView={{ width: 40 }}
      viewport={{ once: true, amount: 0.6 }}
      transition={{ duration: 0.7, ease: EASE }}
    />
  );
}

export function Eyebrow({
  children,
  tone = "dark",
  className = "",
}: {
  children: ReactNode;
  tone?: "dark" | "light";
  className?: string;
}) {
  return (
    <div className={`flex items-center gap-4 ${className}`}>
      <Rule tone={tone === "dark" ? "gold" : "ink"} />
      <span
        className={tone === "dark" ? "eyebrow text-sand/75" : "eyebrow-ink text-[#57514a]"}
      >
        {children}
      </span>
    </div>
  );
}

export function GoldButton({
  children,
  href = "#contact",
  variant = "solid",
  className = "",
}: {
  children: ReactNode;
  href?: string;
  variant?: "solid" | "outline";
  className?: string;
}) {
  const base =
    "group relative inline-flex items-center gap-2.5 rounded-md px-6 py-3.5 text-[14px] font-semibold tracking-[0.01em] transition-all duration-300 will-change-transform";
  const skin =
    variant === "solid"
      ? "bg-gold text-[#14100a] hover:bg-gold-100 hover:-translate-y-0.5 hover:shadow-[0_10px_30px_-12px_rgba(242,180,65,0.65)]"
      : "border border-gold/60 text-gold hover:border-gold hover:bg-gold/10 hover:-translate-y-0.5";
  return (
    <a href={href} className={`${base} ${skin} ${className}`}>
      {children}
      <Arrow />
    </a>
  );
}

export function Arrow({ className = "" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
      className={`h-4 w-4 transition-transform duration-300 group-hover:translate-x-1 ${className}`}
    >
      <path d="M5 12h14M13 6l6 6-6 6" />
    </svg>
  );
}

export function SectionHead({
  eyebrow,
  title,
  tone = "dark",
  className = "",
}: {
  eyebrow: string;
  title: ReactNode;
  tone?: "dark" | "light";
  className?: string;
}) {
  return (
    <div className={className}>
      <Eyebrow tone={tone}>{eyebrow}</Eyebrow>
      <h2
        className={`mt-5 font-display text-[27px] leading-[1.12] font-bold tracking-[-0.02em] sm:text-[34px] ${
          tone === "dark" ? "text-white" : "text-[#17150f]"
        }`}
      >
        {title}
      </h2>
    </div>
  );
}

export { EASE };
