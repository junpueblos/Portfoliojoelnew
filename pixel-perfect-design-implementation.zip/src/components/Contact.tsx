import { Reveal, SectionHead, Arrow } from "./ui";

const FOOTER_LINKS = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Services", href: "#services" },
  { label: "Work", href: "#work" },
  { label: "Contact", href: "#contact" },
];

const SOCIALS = [
  {
    name: "LinkedIn",
    href: "#",
    d: "M4.98 3.5A2.5 2.5 0 112.5 6 2.5 2.5 0 014.98 3.5zM3 8.98h4v12H3zM9.5 8.98h3.8v1.64h.05a4.17 4.17 0 013.75-2.06c4 0 4.75 2.64 4.75 6.07v6.35h-4v-5.63c0-1.34-.02-3.07-1.87-3.07s-2.16 1.46-2.16 2.97v5.73h-4z",
  },
  {
    name: "Facebook",
    href: "#",
    d: "M13.5 21v-8h2.7l.4-3.1h-3.1V7.9c0-.9.25-1.5 1.55-1.5h1.65V3.6A22 22 0 0014.3 3.4c-2.4 0-4 1.46-4 4.15V9.9H7.6V13h2.7v8z",
  },
  {
    name: "Instagram",
    href: "#",
    d: "M12 7.4A4.6 4.6 0 1016.6 12 4.6 4.6 0 0012 7.4zm0 7.6A3 3 0 1115 12a3 3 0 01-3 3zm5.8-7.8a1.07 1.07 0 11-1.07-1.07A1.07 1.07 0 0117.8 7.2zM21 7.24a5.3 5.3 0 00-1.45-3.76A5.34 5.34 0 0015.79 2C14.3 1.92 9.7 1.92 8.21 2a5.32 5.32 0 00-3.76 1.44A5.32 5.32 0 003 7.23c-.08 1.49-.08 6.09 0 7.58a5.3 5.3 0 001.45 3.76A5.35 5.35 0 008.21 20c1.49.09 6.09.09 7.58 0a5.3 5.3 0 003.76-1.45A5.32 5.32 0 0021 14.79c.09-1.49.09-6.08 0-7.57zm-1.92 9.17a3 3 0 01-1.71 1.71c-1.19.47-4 .36-5.37.36s-4.18.1-5.37-.36a3 3 0 01-1.71-1.71c-.47-1.19-.36-4-.36-5.37s-.1-4.18.36-5.37a3 3 0 011.71-1.71c1.19-.47 4-.36 5.37-.36s4.18-.1 5.37.36a3 3 0 011.71 1.71c.47 1.19.36 4 .36 5.37s.11 4.18-.36 5.37z",
  },
  {
    name: "YouTube",
    href: "#",
    d: "M21.6 7.2a2.5 2.5 0 00-1.76-1.77C18.28 5 12 5 12 5s-6.28 0-7.84.43A2.5 2.5 0 002.4 7.2 26 26 0 002 12a26 26 0 00.4 4.8 2.5 2.5 0 001.76 1.77C5.72 19 12 19 12 19s6.28 0 7.84-.43a2.5 2.5 0 001.76-1.77A26 26 0 0022 12a26 26 0 00-.4-4.8zM10 15.1V8.9l5.2 3.1z",
  },
];

export default function Contact() {
  return (
    <>
      {/* ---- CTA band ---- */}
      <section id="contact" className="relative isolate overflow-hidden bg-ink">
        <img
          src="images/cta-desk.jpg"
          alt=""
          aria-hidden
          className="absolute inset-0 h-full w-full object-cover object-right"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/90 to-ink/45" />
        <div className="absolute inset-x-0 top-0 h-px bg-white/[0.06]" />

        <div className="shell relative grid items-center gap-y-9 py-16 lg:grid-cols-[1.35fr_auto] lg:gap-x-14 lg:py-20">
          <div>
            <SectionHead
              eyebrow="Ready to Work Together?"
              title="Let’s Build Something Great"
            />
            <Reveal delay={0.06}>
              <p className="mt-5 max-w-[38rem] text-[15.5px] leading-[1.7] text-mute">
                Whether you need a website, marketing support, automation, or a
                reliable virtual assistant, I&apos;m here to help. Let&apos;s turn
                your ideas into real results.
              </p>
            </Reveal>
          </div>

          <Reveal delay={0.12} className="lg:justify-self-end">
            <div className="flex flex-col items-start gap-5">
              <a
                href="mailto:hello@joelpueblos.com"
                className="group inline-flex items-center gap-2.5 rounded-md bg-gold px-8 py-4 text-[15px] font-semibold text-[#14100a] transition-all duration-300 hover:-translate-y-0.5 hover:bg-gold-100 hover:shadow-[0_16px_38px_-16px_rgba(242,180,65,0.75)]"
              >
                Let&apos;s Talk
                <Arrow />
              </a>
              <p className="flex items-center gap-2.5 text-[13.5px] text-sand/85">
                <svg
                  viewBox="0 0 24 24"
                  className="h-4 w-4 text-gold"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.6"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  aria-hidden
                >
                  <rect x="2.5" y="5" width="19" height="14" rx="1.6" />
                  <path d="M3 6.5l9 6 9-6" />
                </svg>
                Available for Remote &amp; International Clients
              </p>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ---- Footer ---- */}
      <footer className="border-t border-white/[0.07] bg-ink pt-11 pb-9">
        <div className="shell grid gap-y-8 lg:grid-cols-[1.1fr_auto_1fr] lg:items-start lg:gap-x-10">
          <div>
            <a
              href="#home"
              className="font-display text-[19px] font-extrabold tracking-[0.06em] text-white"
            >
              JOEL <span className="text-gold">PUEBLOS</span>
            </a>
            <p className="mt-3 max-w-[26rem] text-[12.5px] leading-relaxed text-mute">
              Technical Virtual Assistant | AI Digital Specialist | Web Design &amp;
              Digital Marketing
            </p>
          </div>

          <nav aria-label="Footer" className="flex flex-wrap gap-x-7 gap-y-3 lg:pt-1.5">
            {FOOTER_LINKS.map((l) => (
              <a
                key={l.label}
                href={l.href}
                className="relative text-[13.5px] text-sand/80 transition-colors duration-300 hover:text-gold after:absolute after:-bottom-1 after:left-0 after:h-px after:w-full after:origin-left after:scale-x-0 after:bg-gold after:transition-transform after:duration-300 hover:after:scale-x-100"
              >
                {l.label}
              </a>
            ))}
          </nav>

          <div className="flex flex-col items-start gap-4 lg:items-end">
            <div className="flex items-center gap-3.5">
              {SOCIALS.map((s) => (
                <a
                  key={s.name}
                  href={s.href}
                  aria-label={s.name}
                  className="text-sand/75 transition-all duration-300 hover:-translate-y-0.5 hover:text-gold"
                >
                  <svg viewBox="0 0 24 24" className="h-[17px] w-[17px]" fill="currentColor" aria-hidden>
                    <path d={s.d} />
                  </svg>
                </a>
              ))}
            </div>

            <div className="flex items-start gap-6 lg:gap-7">
              <p className="text-[12.5px] text-mute lg:text-right">
                © 2024 Joel Pueblos. All rights reserved.
              </p>
              <span
                aria-hidden
                className="hidden h-10 w-px shrink-0 bg-white/[0.12] lg:block"
              />
              <p className="hidden text-right text-[11px] leading-[1.8] tracking-[0.24em] text-sand/70 uppercase lg:block">
                A Smarter
                <br />
                Digital Tomorrow
              </p>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
}
