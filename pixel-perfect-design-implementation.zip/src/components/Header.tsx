import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Arrow, EASE } from "./ui";

const LINKS = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Services", href: "#services" },
  { label: "Work", href: "#work" },
  { label: "Contact", href: "#contact" },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-colors duration-500 ${
        scrolled
          ? "border-b border-white/[0.07] bg-[#0b0a09]/92 backdrop-blur-md"
          : "border-b border-transparent bg-transparent"
      }`}
    >
      <div className="shell flex h-[68px] items-center justify-between gap-6">
        <a
          href="#home"
          className="font-display text-[19px] font-extrabold tracking-[0.06em] text-white sm:text-[21px]"
        >
          JOEL <span className="text-gold">PUEBLOS</span>
        </a>

        <nav aria-label="Primary" className="hidden items-center gap-9 lg:flex">
          {LINKS.map((l) => (
            <a
              key={l.label}
              href={l.href}
              className="group relative py-2 text-[14.5px] font-medium text-sand/85 transition-colors duration-300 hover:text-white"
            >
              {l.label}
              <span className="absolute -bottom-0.5 left-0 h-px w-full origin-left scale-x-0 bg-gold transition-transform duration-300 group-hover:scale-x-100" />
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <a
            href="#contact"
            className="group hidden items-center gap-2 rounded-md bg-gold px-5 py-2.5 text-[14px] font-semibold text-[#14100a] transition-all duration-300 hover:-translate-y-0.5 hover:bg-gold-100 hover:shadow-[0_10px_26px_-14px_rgba(242,180,65,0.8)] sm:inline-flex"
          >
            Let&apos;s Talk
            <Arrow />
          </a>

          <button
            type="button"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
            className="flex h-10 w-10 items-center justify-center rounded-md border border-white/12 text-sand transition-colors hover:border-gold/60 hover:text-gold lg:hidden"
          >
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
              {open ? <path d="M6 6l12 12M18 6L6 18" /> : <path d="M4 8h16M4 16h16" />}
            </svg>
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.4, ease: EASE }}
            className="overflow-hidden border-t border-white/[0.07] bg-[#0b0a09]/97 backdrop-blur-md lg:hidden"
          >
            <nav aria-label="Mobile" className="shell flex flex-col py-3">
              {LINKS.map((l, i) => (
                <motion.a
                  key={l.label}
                  href={l.href}
                  onClick={() => setOpen(false)}
                  initial={{ opacity: 0, x: -12 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.35, delay: 0.05 * i, ease: EASE }}
                  className="flex items-center justify-between border-b border-white/[0.06] py-3.5 text-[15px] text-sand/90 transition-colors hover:text-gold"
                >
                  {l.label}
                  <span className="text-gold/60">
                    <Arrow className="!h-3.5 !w-3.5" />
                  </span>
                </motion.a>
              ))}
              <a
                href="#contact"
                onClick={() => setOpen(false)}
                className="mt-4 mb-3 inline-flex items-center justify-center gap-2 rounded-md bg-gold px-5 py-3 text-[14px] font-semibold text-[#14100a]"
              >
                Let&apos;s Talk <Arrow />
              </a>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
